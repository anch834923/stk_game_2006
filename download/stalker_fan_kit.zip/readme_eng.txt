S.T.A.L.K.E.R.: Oblivion Lost Fansite Kit
Copyright 2003, GSC Game World.
Release Date: 14/02/03

(Instructions Appear License Agreement.  Be sure you have fully read and understand this agreement before using any of the assets included in this packaged file!)

-------------------------

FAN SITE END USER LICENSE

GSC Game World ("GSC") grants you a non- transferable license to download one copy of the graphics and other materials accompanying this license (the "Materials"), onto a single computer solely for your personal noncommercial use of the Materials on your Fan Site. "Fan Site" shall mean a personal, noncommercial web site, created by you, that is freely accessible to the public and dedicated to promoting one or more games developed by GSC. 

GSC owns all of the rights in the Materials.  You may not alter the GSC's logo included in the Materials. Your right to use Materials is limited to the license grant above, and you may not otherwise copy, display, perform, publish, or use any of the Materials.  You may not modify, reverse engineer, disassemble, create derivative works from, license, transfer, distribute, or sell any Materials, or use the Materials to further any commercial or unlawful purpose.  Without limiting the foregoing, you may not use the Materials to sell advertising, to promote another product or business, or on any site that operates or promotes a server emulator.  You may not make the Materials available by download from your Fan Site. 

If you post the Materials on Fan Site, you must also post the following notice on your Fan Site: "Game content and materials copyright GSC Game World.  All rights reserved." 
You will not represent that your Fan Site is endorsed or approved by GSC or that any other content on your Fan Site is endorsed or approved by GSC.

GSC does not represent or warrant that you will be able to use any of the Materials. You expressly agree that your use of the Materials is at your sole risk. The Materials are provided on an "as is," "as available" basis. GSC disclaims all implied warranties and conditions, including without limitation any implied warranties of merchantability, fitness for a particular purpose, or non-infringement of third party rights. GSC assumes no responsibility for any damages suffered by you. At GSC's request, you agree to defend, indemnify and hold harmless GSC from all liabilities, claims and expenses, including attorneys' fees, arising from any breach of this License by you.

GSC makes the Materials available at its site located in the United States.  
You are solely responsible for knowing and complying with all federal, state, and local laws that may apply to your use of Materials in your own locale. By downloading the Materials, you warrant that you are not located in any country, or exporting the Materials to any person or place, to which the United States has embargoed goods.

GSC may terminate this License at any time.  Upon termination, you must destroy all Materials. 
This License is governed by California law (without regard to conflicts of law), and is the entire agreement between GSC and you regarding the Materials.

NOTE: The Materials in Backgrounds folder of the Fansite kit must NOT be used as screenshots on your fan-site and serve merely for the purpose of filling the background of your fan-site pages.
